#!/usr/bin/python3
for n in range(97, 123):
    if chr(n) != 'q' and chr(n) != 'e':
        print("{}".format(chr(n)), end="")

More on data structure in python

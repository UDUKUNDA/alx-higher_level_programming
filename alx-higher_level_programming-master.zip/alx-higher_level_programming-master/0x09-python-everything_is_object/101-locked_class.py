#!/usr/bin/python3

class LockedClass:
    __slots__ = ["first_name"]

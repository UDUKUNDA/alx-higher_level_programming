This project is going to be all about input output in python

#!/usr/bin/python3
"""Defines a class called Rectangle."""


class Rectangle:
    """ This one right Represent a rectangle."""
    pass


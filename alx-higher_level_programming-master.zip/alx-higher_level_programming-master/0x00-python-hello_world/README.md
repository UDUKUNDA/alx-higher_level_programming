This the first project in high level language

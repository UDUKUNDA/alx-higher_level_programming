This is the peoject about python exception

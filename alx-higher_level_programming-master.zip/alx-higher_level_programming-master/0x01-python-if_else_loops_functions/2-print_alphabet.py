#!/usr/bin/python3
for n in range(97, 123):
    print("{}".format(chr(n)), end="")

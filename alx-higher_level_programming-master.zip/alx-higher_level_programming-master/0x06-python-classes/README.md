This one right here is going to be all about python classes

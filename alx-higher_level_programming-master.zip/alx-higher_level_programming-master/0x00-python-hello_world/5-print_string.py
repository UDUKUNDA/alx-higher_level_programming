#!/usr/bin/python3
str = "Holberton School"
print(3 * str)
print(str[:9])

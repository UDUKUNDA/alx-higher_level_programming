#!/usr/bin/python3
def number_keys(a_dictionary):
    n = 0
    keys = list(a_dictionary.keys())

    for i in keys:
        n += 1

    return (n)

#!/usr/bin/python3
"""The following will define  a class Square."""


class Square:
    """The class is called  a square."""
    pass

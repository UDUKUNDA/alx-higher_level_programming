Introduction to inheritance
